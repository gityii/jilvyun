<?php
/**
 * Created by PhpStorm.
 * User: v_ransu
 * Date: 2018/1/8
 * Time: 16:08
 */
namespace app\display\controllers;

use base\controllers\db;
use base\controllers\web;
use base\controllers\page;
use base\controllers\file;

class display
{
    public static function jiti()
    {

        $msg = array();
        $success = false;
        $error = '';

        web::layout('/admin/views/layout/admin');
        web::render('/display/views/jiti', array(
            'success' => $success,
            'error' => $error,
            'msg' => $msg
        ));
    }

    public static function category()
    {

        $msg = array();
        $success = false;
        $error = '';

        $result = db::query_get('select `family`, count(`family`) as family_count from `t_group` group by `family`');

        echo json_encode($result);
    }

    public static function project()
    {

        $msg = array();
        $success = false;
        $error = '';

        $result = db::query_get('select `project`, count(`project`) as project_count from `t_group` group by `project`');


        echo json_encode($result);
    }



    public static function banjifenxi()
    {

        $grades = db::query_get('select `grade` from `t_grade`');
       // web::layout('admin/views/layout/admin');
        web::render('display/views/banjifenxi',array(
            'grades'=>$grades
        ));
    }



    public static function banji()
    {
        $grade = web::get('grade');
        $where = '';
        $result = array();

        if (!empty($grade))
        {
            $where = ' where `grade`=\''.$grade.'\'';
        }

        $classes = db::query_get('select `class` from `t_school`'.$where);

        foreach ($classes as $k=>$v)
        {
            $result[] = db::query_get('select `project`, count(1) as counts from `t_group`' . $where . 'and `class`=\''.$v['class'].'\' group by `project`');
            $result[$k][] = $v['class'];
        }

        $count = count($result,COUNT_NORMAL);

        $alls[] = db::query_get('select DISTINCT `project` ,count(1) as counts from `t_group` group by `project`');

        foreach ($alls as $k=>$v){
            $result[$count] = $v;
        }

        echo json_encode($result);
    }


    public static function test()
    {


        $seriesdata = array(
        [['project'=> '包租费','count'=> 20], ['project'=>'装修费','count'=> 10], ['project'=>'保洁费', 'count'=> 1], ['project'=>'物业费','count'=> 7],'新虹桥'],
        [['project'=>'包租费', 'count'=> 25], ['project'=>'装修费', 'count'=> 7], ['project'=>'保洁费', 'count'=> 7],'中山公园'],
        [['project'=>'包租费', 'count'=> 41], ['project'=>'装修费', 'count'=> 9], ['project'=>'保洁费', 'count'=> 31], ['project'=>'物业费', 'count'=> 20],'虹桥'],
        [['project'=>'包租费', 'count'=> 15], ['project'=>'装修费', 'count'=> 45], ['project'=>'保洁费', 'count'=> 21], ['project'=>'物业费', 'count'=> 10],'镇宁路'],
        [['project'=>'包租费', 'count'=> 20], ['project'=>'装修费', 'count'=> 5], ['project'=>'保洁费', 'count'=> 15], '天山古北'],
        [['project'=>'包租费', 'count'=> 100], ['project'=>'装修费', 'count'=> 100], ['project'=>'保洁费', 'count'=> 100], ['project'=>'物业费', 'count'=> 100]]
        );

        //$result = array($legenddata, $xdata, $seriesdata);


        echo json_encode($seriesdata);
    }
}
